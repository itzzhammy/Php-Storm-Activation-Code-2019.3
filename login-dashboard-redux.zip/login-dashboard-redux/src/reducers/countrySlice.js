import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  fetchedCountries: [],
  error: "",
};

// Generating action types using Thunk
export const fetchCountry = createAsyncThunk("country/fetchCountry", async () => {
    const response = await fetch("https://restcountries.com/v3.1/all");
    const data = await response.json();
    return data;
  }
);

// Dashboard Data Slicing

const countrytSlice = createSlice({
  name: "country",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(fetchCountry.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchCountry.fulfilled, (state, action) => {
      state.loading = false;
      state.fetchedCountries = action.payload;
      state.error = "";
    });
    builder.addCase(fetchCountry.rejected, (state, action) => {
      state.loading = false;
      state.fetchedCountries = [];
      state.error = action.error.message;
    });
  },
});

export default countrytSlice.reducer;
