import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchCountry } from "../reducers/countrySlice";
import AccordionCity from "../components/atomicComponents/AccordionCity";
import { Stack } from "@mui/material";
import { TailSpin } from "react-loader-spinner";

const CountryView = () => {
    
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchCountry());
    }, []);

    const countryList = useSelector((state) => state.countryList);

    return (
        <>
            <Stack flexDirection="row" justifyContent="center" alignItems="center">
                {countryList.loading && !countryList.error ? (
                    <TailSpin
                        height="80"
                        width="80"
                        radius="9"
                        color="green"
                        ariaLabel="three-dots-loading"
                    />
                ) : (
                    <AccordionCity />
                )}
            </Stack>
        </>
    );
};

export default CountryView;