import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getCountries } from "../reducers/countrySlice";
import AccordionCountry from "../components/atomicComponents/AccordionCountry";
import { Stack } from "@mui/material";
import { TailSpin } from "react-loader-spinner";

const CountryView = () => {
    
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getCountries());
    }, []);

    const countryList = useSelector((state) => state.countryList);

    return (
        <>
            <Stack flexDirection="row" justifyContent="center" alignItems="center">
                {countryList.loading && !countryList.error ? (
                    <TailSpin
                        height="80"
                        width="80"
                        radius="9"
                        color="green"
                        ariaLabel="three-dots-loading"
                    />
                ) : (
                    <AccordionCountry />
                )}
            </Stack>
        </>
    );
};

export default CountryView;