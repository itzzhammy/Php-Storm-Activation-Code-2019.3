<?php
/**
 * Salient studio templates
 *
 * All studio templates have been moved to the Salient Core plugin.
 *
 * @version 10.5
 */

?>