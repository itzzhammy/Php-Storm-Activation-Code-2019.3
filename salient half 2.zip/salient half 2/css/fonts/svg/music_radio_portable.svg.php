<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="22" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="38"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="20" cy="41" r="13"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="36" x2="32" y2="36"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="46" x2="32" y2="46"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="25" y1="29" x2="25" y2="53"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="15" y1="29" x2="15" y2="53"/>
<rect x="43" y="28" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="5" height="4"/>
<rect x="52" y="28" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="5" height="4"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="52" cy="49" r="5"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="52" y1="44" x2="52" y2="48"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="3,22 3,18 9,18 9,22 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="53,4 6,16 6,18 "/>
</svg>
