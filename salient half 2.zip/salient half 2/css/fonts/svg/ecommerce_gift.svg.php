<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="18" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="9"/>
<rect x="6" y="27" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="52" height="31"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="58" x2="32" y2="18"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,18c0,0-13,0.101-13-9c0-7,13-4.068,13,2
	C32,17.067,32,18,32,18z"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,18c0,0,13,0.101,13-9c0-7-13-4.068-13,2
	C32,17.067,32,18,32,18z"/>
</svg>
