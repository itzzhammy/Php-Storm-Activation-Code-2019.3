<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="38,51 23,9 22,9 7,51 	"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="35" x2="13" y2="35"/>
</g>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M44,34c0,0,1.5-2,5.5-2s5.5,3,5.5,5s0,10,0,10
	s0,3,2.5,3"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M55,40h-5c0,0-7,0-7,5s4,5,5,5s7,0,7-7"/>
<rect x="1" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="62"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="6" y1="55" x2="58" y2="55"/>
</svg>
