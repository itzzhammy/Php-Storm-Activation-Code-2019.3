<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="31"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M23,2c13.242,3.528,22,15.646,22,30
	c0,14.355-8.756,26.473-22,30"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="30" y1="59" x2="47" y2="59"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="37" y1="53" x2="55" y2="53"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="42" y1="47" x2="59" y2="47"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="44" y1="41" x2="62" y2="41"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="45" y1="35" x2="63" y2="35"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="45" y1="29" x2="63" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="44" y1="23" x2="62" y2="23"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="41" y1="17" x2="59" y2="17"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="37" y1="11" x2="55" y2="11"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="30" y1="5" x2="47" y2="5"/>
</svg>
