<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="5" cy="59" r="4"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M23,29c-3.124,3.124-3.124,8.876,0,12
	c3.124,3.124,8.876,2.124,12-1"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="23" y1="29" x2="51" y2="1"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="35" y1="40" x2="63" y2="12"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="23" y1="41" x2="8" y2="56"/>
</svg>
