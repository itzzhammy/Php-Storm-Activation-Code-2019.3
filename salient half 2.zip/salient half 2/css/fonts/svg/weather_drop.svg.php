<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M11,41.265C11.052,53.27,20.401,63,32,63
		s21-9.73,21-21.735C53,25.729,32.035,1,32.035,1S10.931,25.729,11,41.265z"/>
</g>
</svg>
